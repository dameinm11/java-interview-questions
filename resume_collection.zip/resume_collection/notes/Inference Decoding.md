---
title: Inference Decoding
created: '2026-06-04T17:24:20.227Z'
modified: '2026-06-04T18:05:19.728Z'
---

# Inference Decoding

https://github.com/ds-hwang/wiki/blob/master/Video-acceleration/HTMLVideoArchAndroid_New.png

https://github.com/ritwikareddykancharla/amazon-interview-prep/wiki/Advanced-Scenario-Pack#-advanced-ml-degradation--drift-scenarios

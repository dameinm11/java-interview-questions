---
title: Stored Procedures
created: '2026-06-04T17:15:43.477Z'
modified: '2026-06-04T21:34:38.506Z'
---

# Stored Procedures

```sql
ALTER INDEX IX_IndexName ON Schema.TableName DISABLE;
GO
```

```sql
ALTER INDEX IX_IndexName ON Schema.TableName REBUILD;
GO
```

```sql
DROP INDEX IndexName ON Schema.TableName;
GO
```

```sql
Transact-SQL
CREATE PROCEDURE Get_OrderID_OrderQty
@ProductID INT
AS
 
SELECT SalesOrderDetailID, OrderQty
FROM Sales.SalesOrderDetail
WHERE ProductID = @ProductID;
```


webhooks realtime api for data flow deutschland

https://appsoracle-abhi.blogspot.com/2019/09/using-invokers-rights-versus-definers.html

https://github.com/wenshao/sql-dialects/tree/acc6698bf87709c16156862d295b2a4bb290cec1/advanced/stored-procedures


Nexo Retailer Protocol Specifications:
https://github.com/prathanbomb/nexo-retailer-protocol/blob/8e2901a35871abe808e0bfee1f76ce430d4e36f6/FIELD_REGISTRY.md



https://www.paystand.com/blog/merchant-identification-number

https://www.brentozar.com/archive/2013/06/the-elephant-and-the-mouse-or-parameter-sniffing-in-sql-server/

https://github.com/tsinglinrain/WeChatPay_to_Notion

https://github.com/njorogepaul-moghul/Java_based-Juice-POS-system/tree/main

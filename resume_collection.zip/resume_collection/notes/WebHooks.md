---
title: WebHooks
created: '2026-06-04T17:04:32.098Z'
modified: '2026-06-04T18:05:51.516Z'
---

# WebHooks

https://docs.adyen.com/development-resources/webhooks/webhook-types?programming_language=xml

https://docs.adyen.com/point-of-sale/design-your-integration/terminal-api


